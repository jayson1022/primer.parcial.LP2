﻿using System;
using System.Collections.Generic;

namespace primer.parcial.Models;

public partial class Actividade
{
    public int IdActividad { get; set; }

    public string Nombre { get; set; } = null!;

    public DateTime Fecha { get; set; }

    public int IdDestino { get; set; }

    public virtual Destino IdDestinoNavigation { get; set; } = null!;

    public virtual ICollection<Reserva> IdReservas { get; set; } = new List<Reserva>();
}
