﻿using System;
using System.Collections.Generic;

namespace primer.parcial.Models;

public partial class Vuelo
{
    public int IdVuelo { get; set; }

    public string Aerolinea { get; set; } = null!;

    public string NumeroDeVuelo { get; set; } = null!;

    public DateTime Fecha { get; set; }

    public int IdDestino { get; set; }

    public virtual Destino IdDestinoNavigation { get; set; } = null!;

    public virtual ICollection<Reserva> IdReservas { get; set; } = new List<Reserva>();
}
