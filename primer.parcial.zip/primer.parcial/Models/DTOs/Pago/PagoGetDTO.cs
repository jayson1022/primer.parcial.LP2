﻿namespace primer.parcial.Models.DTOs.Pago
{
    public class PagoGetDTO
    {
        public int IdPago { get; set; }

        public decimal Monto { get; set; }

        public DateTime Fecha { get; set; }

        public int IdReserva { get; set; }

        public virtual Reserva IdReservaNavigation { get; set; } = null!;
    }
}
