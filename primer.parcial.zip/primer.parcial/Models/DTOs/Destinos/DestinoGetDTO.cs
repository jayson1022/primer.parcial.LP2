﻿namespace primer.parcial.Models.DTOs.Destinos
{
    public class DestinoGetDTO
    {
        public int IDdestino { get; set; }
        public string Ciudad { get; set; }
        public string Pais { get; set; }
        public List<Vuelo> Vuelos { get; set; }
        public List<Hotel> Hotel { get; set; }
        public List<Auto> Autos { get; set; }
        public List<Actividade> Actividad { get; set; }
    }
}
