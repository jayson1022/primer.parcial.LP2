﻿using AutoMapper;
using primer.parcial.Models.DTOs.Actividades;
using primer.parcial.Models.DTOs.Autos;
using primer.parcial.Models.DTOs.Clientes;
using primer.parcial.Models.DTOs.Destinos;
using primer.parcial.Models.DTOs.Reservas;
using primer.parcial.Models.DTOs.Vuelos;
using primer.parcial.Models.DTOs.Hotel;
using primer.parcial.Models.DTOs.Pago;

using primer.parcial.Models;
namespace primer.parcial.Models.DTOs.Actividades
{
    public class AutoMapperProfile: Profile
    {
        public AutoMapperProfile() 
        {
            CreateMap<ActividadGetDTO, Actividade>().ReverseMap();
            CreateMap<ActividadInsertDTO, Actividade>().ReverseMap();
            CreateMap<ActividadUpdateDTO, Actividade>().ReverseMap();
        
        }
    }
}

namespace primer.parcial.Models.DTOs.Autos
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<AutoGetDTO, Auto>().ReverseMap();
            CreateMap<AutoInsertDTO, Auto>().ReverseMap();
            CreateMap<AutoUpdateDTO, Auto>().ReverseMap();

        }
    }
}

namespace primer.parcial.Models.DTOs.Clientes

{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<ClienteGetDTO, Cliente>().ReverseMap();
            CreateMap<ClienteInsertDTO, Cliente>().ReverseMap();
            CreateMap<ClienteUpdateDTO, Cliente>().ReverseMap();

        }
    }
}

namespace primer.parcial.Models.DTOs.Destinos

{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<DestinoGetDTO, Destino>().ReverseMap();
            CreateMap<DestinoInsertDTO, Destino>().ReverseMap();
            CreateMap<DestinoUpdateDTO, Destino>().ReverseMap();

        }
    }
}



namespace primer.parcial.Models.DTOs.Reservas

{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<ReservaGetDTO, Reserva>().ReverseMap();
            CreateMap<ReservaInsertDTO, Reserva>().ReverseMap();
            CreateMap<ReservaUpdateDTO, Reserva>().ReverseMap();

        }
    }
}

namespace primer.parcial.Models.DTOs.Vuelos

{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<VueloGetDTO, Vuelo>().ReverseMap();
            CreateMap<VueloInsertDTO, Vuelo>().ReverseMap();
            CreateMap<VueloUpdateDTO, Vuelo>().ReverseMap();

        }
    }
}

namespace primer.parcial.Models.DTOs.Hotel

{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<HotelGetDTO, Hotel>().ReverseMap();
            CreateMap<HotelInsertDTO, Hotel>().ReverseMap();
            CreateMap<HotelUpdateDTO, Hotel>().ReverseMap();

        }
    }
}


namespace primer.parcial.Models.DTOs.Pago

{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<PagoGetDTO, Pago>().ReverseMap();
            CreateMap<PagoInsertDTO, Pago>().ReverseMap();
            CreateMap<PagoUpdateDTO, Pago>().ReverseMap();

        }
    }
}