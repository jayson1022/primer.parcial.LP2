﻿namespace primer.parcial.Models.DTOs.Hotel
{
    public class HotelUpdateDTO
    {
        public int IdHotel { get; set; }

        public string Nombre { get; set; } = null!;

        public int IdDestino { get; set; }

        public virtual Destino IdDestinoNavigation { get; set; } = null!;

        public virtual ICollection<Reserva> IdReservas { get; set; } = new List<Reserva>();
    }
}
