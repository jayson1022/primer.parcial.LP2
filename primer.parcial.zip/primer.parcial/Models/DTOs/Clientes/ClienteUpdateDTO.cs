﻿using System.ComponentModel.DataAnnotations;

namespace primer.parcial.Models.DTOs.Clientes
{
    public class ClienteUpdateDTO
    {
        [Required(ErrorMessage = "Id es requerido")]
        public int IDcliente { get; set; }
        [Required(ErrorMessage = "Nombre es requerido")]
        [MaxLength(100, ErrorMessage = "Nombre no puede ser mayor a 100 carácteres")]
        public string Nombre { get; set; } = null!;
        public string Email { get; set; }
        public List<Reserva> Reserva { get; set; }
    }
}
