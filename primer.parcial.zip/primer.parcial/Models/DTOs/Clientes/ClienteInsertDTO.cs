﻿using System.ComponentModel.DataAnnotations;

namespace primer.parcial.Models.DTOs.Clientes
{
    public class ClienteInsertDTO
    {
        [Required(ErrorMessage = "Nombre es requerido")]
        [MaxLength(100, ErrorMessage = "Nombre no puede ser mayor a 100 carácteres")]
        public int IDcliente { get; set; }
        public string Nombre { get; set; } = null!;
        public string Email { get; set; }
        public List<Reserva> Reserva { get; set; }
    }
}
