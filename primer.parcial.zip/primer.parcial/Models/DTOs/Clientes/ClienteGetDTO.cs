﻿namespace primer.parcial.Models.DTOs.Clientes
{
    public class ClienteGetDTO
    {
        public int IDcliente { get; set; }
        public string Nombre { get; set; } = null!;
        public string Email { get; set; }
        public List<Reserva> Reserva { get; set; }
    }
}
