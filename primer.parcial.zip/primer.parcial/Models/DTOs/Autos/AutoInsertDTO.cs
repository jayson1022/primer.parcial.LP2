﻿namespace primer.parcial.Models.DTOs.Autos
{
    public class AutoInsertDTO
    {
        public int IDauto { get; set; }
        public string Modelo { get; set; }
        public int IDdestino { get; set; }
        public Destino destino { get; set; }
        public List<Reserva> reserva { get; set; }
    }
}
