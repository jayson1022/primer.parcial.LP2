﻿namespace primer.parcial.Models.DTOs.Vuelos
{
    public class VueloUpdateDTO
    {
        public int IdVuelo { get; set; }

        public string Aerolinea { get; set; } = null!;

        public string NumeroDeVuelo { get; set; } = null!;

        public DateTime Fecha { get; set; }

        public int IdDestino { get; set; }

        public virtual Destino IdDestinoNavigation { get; set; } = null!;

        public virtual ICollection<Reserva> IdReservas { get; set; } = new List<Reserva>();
    }
}

