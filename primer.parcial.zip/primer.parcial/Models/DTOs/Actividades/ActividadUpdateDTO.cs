﻿namespace primer.parcial.Models.DTOs.Actividades
{
    public class ActividadUpdateDTO
    {
        public int Idactividad { get; set; }
        public string Nombre { get; set; } = null!;
        public DateTime Fecha { get; set; }
        public int? Iddesstino { get; set; }
        public Destino Destino { get; set; }
        public List<Reserva> Reserva { get; set; }
    }
}
