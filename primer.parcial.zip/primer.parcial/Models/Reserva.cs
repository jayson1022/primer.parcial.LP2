﻿using System;
using System.Collections.Generic;

namespace primer.parcial.Models;

public partial class Reserva
{
    public int IdReserva { get; set; }

    public int IdCliente { get; set; }

    public virtual Cliente IdClienteNavigation { get; set; } = null!;

    public virtual ICollection<Pago> Pagos { get; set; } = new List<Pago>();

    public virtual ICollection<Actividade> IdActividads { get; set; } = new List<Actividade>();

    public virtual ICollection<Auto> IdAutos { get; set; } = new List<Auto>();

    public virtual ICollection<Hotel> IdHotels { get; set; } = new List<Hotel>();

    public virtual ICollection<Vuelo> IdVuelos { get; set; } = new List<Vuelo>();
}
