﻿using System;
using System.Collections.Generic;

namespace primer.parcial.Models;

public partial class Destino
{
    public int IdDestino { get; set; }

    public string Ciudad { get; set; } = null!;

    public string Pais { get; set; } = null!;

    public virtual ICollection<Actividade> Actividades { get; set; } = new List<Actividade>();

    public virtual ICollection<Auto> Autos { get; set; } = new List<Auto>();

    public virtual ICollection<Hotel> Hotels { get; set; } = new List<Hotel>();

    public virtual ICollection<Vuelo> Vuelos { get; set; } = new List<Vuelo>();
}
