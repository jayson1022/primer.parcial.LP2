﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace primer.parcial.Models;

public partial class ViajesContext : DbContext
{
    public ViajesContext()
    {
    }

    public ViajesContext(DbContextOptions<ViajesContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Actividade> Actividades { get; set; }

    public virtual DbSet<Auto> Autos { get; set; }

    public virtual DbSet<Cliente> Clientes { get; set; }

    public virtual DbSet<Destino> Destinos { get; set; }

    public virtual DbSet<Hotel> Hotels { get; set; }

    public virtual DbSet<Pago> Pagos { get; set; }

    public virtual DbSet<Reserva> Reservas { get; set; }

    public virtual DbSet<Vuelo> Vuelos { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=JAYSON;Database=Viajes;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Actividade>(entity =>
        {
            entity.HasKey(e => e.IdActividad).HasName("PK__Activida__D4A072CF9E6DB0B0");

            entity.Property(e => e.IdActividad).HasColumnName("ID_actividad");
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.IdDestino).HasColumnName("ID_destino");
            entity.Property(e => e.Nombre).HasMaxLength(100);

            entity.HasOne(d => d.IdDestinoNavigation).WithMany(p => p.Actividades)
                .HasForeignKey(d => d.IdDestino)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Actividad__ID_de__46E78A0C");
        });

        modelBuilder.Entity<Auto>(entity =>
        {
            entity.HasKey(e => e.IdAuto).HasName("PK__Autos__64DA47BB2F25DEFF");

            entity.Property(e => e.IdAuto).HasColumnName("ID_auto");
            entity.Property(e => e.IdDestino).HasColumnName("ID_destino");
            entity.Property(e => e.Modelo).HasMaxLength(100);

            entity.HasOne(d => d.IdDestinoNavigation).WithMany(p => p.Autos)
                .HasForeignKey(d => d.IdDestino)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Autos__ID_destin__440B1D61");
        });

        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.IdCliente).HasName("PK__Clientes__9BB2655B43B9A2E5");

            entity.Property(e => e.IdCliente).HasColumnName("ID_cliente");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.Nombre).HasMaxLength(100);
        });

        modelBuilder.Entity<Destino>(entity =>
        {
            entity.HasKey(e => e.IdDestino).HasName("PK__Destinos__A0811A4C8F1178C2");

            entity.Property(e => e.IdDestino).HasColumnName("ID_destino");
            entity.Property(e => e.Ciudad).HasMaxLength(100);
            entity.Property(e => e.Pais).HasMaxLength(100);
        });

        modelBuilder.Entity<Hotel>(entity =>
        {
            entity.HasKey(e => e.IdHotel).HasName("PK__Hotel__8C81B30A380B7841");

            entity.ToTable("Hotel");

            entity.Property(e => e.IdHotel).HasColumnName("ID_hotel");
            entity.Property(e => e.IdDestino).HasColumnName("ID_destino");
            entity.Property(e => e.Nombre).HasMaxLength(100);

            entity.HasOne(d => d.IdDestinoNavigation).WithMany(p => p.Hotels)
                .HasForeignKey(d => d.IdDestino)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Hotel__ID_destin__412EB0B6");
        });

        modelBuilder.Entity<Pago>(entity =>
        {
            entity.HasKey(e => e.IdPago).HasName("PK__Pago__808903EC3AE50BF6");

            entity.ToTable("Pago");

            entity.Property(e => e.IdPago).HasColumnName("ID_pago");
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.IdReserva).HasColumnName("ID_reserva");
            entity.Property(e => e.Monto).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.IdReservaNavigation).WithMany(p => p.Pagos)
                .HasForeignKey(d => d.IdReserva)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Pago__ID_reserva__49C3F6B7");
        });

        modelBuilder.Entity<Reserva>(entity =>
        {
            entity.HasKey(e => e.IdReserva).HasName("PK__Reservas__CD692CB00C8D503D");

            entity.Property(e => e.IdReserva).HasColumnName("ID_reserva");
            entity.Property(e => e.IdCliente).HasColumnName("ID_cliente");

            entity.HasOne(d => d.IdClienteNavigation).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.IdCliente)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reservas__ID_cli__3B75D760");

            entity.HasMany(d => d.IdActividads).WithMany(p => p.IdReservas)
                .UsingEntity<Dictionary<string, object>>(
                    "ReservaActividad",
                    r => r.HasOne<Actividade>().WithMany()
                        .HasForeignKey("IdActividad")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ReservaAc__ID_ac__59063A47"),
                    l => l.HasOne<Reserva>().WithMany()
                        .HasForeignKey("IdReserva")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ReservaAc__ID_re__5812160E"),
                    j =>
                    {
                        j.HasKey("IdReserva", "IdActividad").HasName("PK__ReservaA__20232B9CA8C36315");
                        j.ToTable("ReservaActividad");
                        j.IndexerProperty<int>("IdReserva").HasColumnName("ID_reserva");
                        j.IndexerProperty<int>("IdActividad").HasColumnName("ID_actividad");
                    });

            entity.HasMany(d => d.IdAutos).WithMany(p => p.IdReservas)
                .UsingEntity<Dictionary<string, object>>(
                    "ReservaAuto",
                    r => r.HasOne<Auto>().WithMany()
                        .HasForeignKey("IdAuto")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ReservaAu__ID_au__5535A963"),
                    l => l.HasOne<Reserva>().WithMany()
                        .HasForeignKey("IdReserva")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ReservaAu__ID_re__5441852A"),
                    j =>
                    {
                        j.HasKey("IdReserva", "IdAuto").HasName("PK__ReservaA__6B2488CB79B92517");
                        j.ToTable("ReservaAuto");
                        j.IndexerProperty<int>("IdReserva").HasColumnName("ID_reserva");
                        j.IndexerProperty<int>("IdAuto").HasColumnName("ID_auto");
                    });

            entity.HasMany(d => d.IdHotels).WithMany(p => p.IdReservas)
                .UsingEntity<Dictionary<string, object>>(
                    "ReservaHotel",
                    r => r.HasOne<Hotel>().WithMany()
                        .HasForeignKey("IdHotel")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ReservaHo__ID_ho__5165187F"),
                    l => l.HasOne<Reserva>().WithMany()
                        .HasForeignKey("IdReserva")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ReservaHo__ID_re__5070F446"),
                    j =>
                    {
                        j.HasKey("IdReserva", "IdHotel").HasName("PK__ReservaH__75A13780FF3D1B01");
                        j.ToTable("ReservaHotel");
                        j.IndexerProperty<int>("IdReserva").HasColumnName("ID_reserva");
                        j.IndexerProperty<int>("IdHotel").HasColumnName("ID_hotel");
                    });

            entity.HasMany(d => d.IdVuelos).WithMany(p => p.IdReservas)
                .UsingEntity<Dictionary<string, object>>(
                    "ReservaVuelo",
                    r => r.HasOne<Vuelo>().WithMany()
                        .HasForeignKey("IdVuelo")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ReservaVu__ID_vu__4D94879B"),
                    l => l.HasOne<Reserva>().WithMany()
                        .HasForeignKey("IdReserva")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ReservaVu__ID_re__4CA06362"),
                    j =>
                    {
                        j.HasKey("IdReserva", "IdVuelo").HasName("PK__ReservaV__49B02A2A342A528A");
                        j.ToTable("ReservaVuelo");
                        j.IndexerProperty<int>("IdReserva").HasColumnName("ID_reserva");
                        j.IndexerProperty<int>("IdVuelo").HasColumnName("ID_vuelo");
                    });
        });

        modelBuilder.Entity<Vuelo>(entity =>
        {
            entity.HasKey(e => e.IdVuelo).HasName("PK__Vuelos__4D9069A92EF57D5E");

            entity.Property(e => e.IdVuelo).HasColumnName("ID_vuelo");
            entity.Property(e => e.Aerolinea).HasMaxLength(100);
            entity.Property(e => e.Fecha).HasColumnType("datetime");
            entity.Property(e => e.IdDestino).HasColumnName("ID_destino");
            entity.Property(e => e.NumeroDeVuelo).HasMaxLength(100);

            entity.HasOne(d => d.IdDestinoNavigation).WithMany(p => p.Vuelos)
                .HasForeignKey(d => d.IdDestino)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vuelos__ID_desti__3E52440B");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
