﻿using System;
using System.Collections.Generic;

namespace primer.parcial.Models;

public partial class Auto
{
    public int IdAuto { get; set; }

    public string Modelo { get; set; } = null!;

    public int IdDestino { get; set; }

    public virtual Destino IdDestinoNavigation { get; set; } = null!;

    public virtual ICollection<Reserva> IdReservas { get; set; } = new List<Reserva>();
}
